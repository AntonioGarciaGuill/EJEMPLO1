﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;


namespace prueba1.Pages
{
  
        public class IndexModel : PageModel
    {
    
        private readonly ILogger<IndexModel> _logger;
        
        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
    
        public void OnGet()
        {


        }
         public void OnPost(string email)
        {
            var smtp = new System.Net.Mail.SmtpClient();
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.Host = "smtp.office365.com";  //smtp.office365.com
            smtp.Credentials = new System.Net.NetworkCredential("marisela.ordaz@my.unitec.edu.mx", "20033332");

            var mail = new System.Net.Mail.MailMessage();
            mail.To.Add(email);
            mail.Subject = "Gracias por suscribirte :)";
            mail.Body = $"<h1>Hola ahora recibiras cada que tengamos ofertas disponibles</h1>";
            mail.Body =$"<img src='Poster.jpg' />";
            mail.IsBodyHtml = true;
            mail.From = new System.Net.Mail.MailAddress("marisela.ordaz@my.unitec.edu.mx", "AnimeRy");
            smtp.Send(mail);
        }
    }
}
