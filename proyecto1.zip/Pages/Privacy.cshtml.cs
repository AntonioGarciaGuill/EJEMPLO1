﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Data.SqlClient;
namespace prueba1.Pages
{
   public class alumnos
    {
        public Guid Id;
        public string Nombre;
        public int cuenta;
        public double promedio;
    }
    public class PrivacyModel : PageModel
    {
        private readonly ILogger<PrivacyModel> _logger;

        public List<alumnos> alumno = new List<alumnos>{};

        public PrivacyModel(ILogger<PrivacyModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
             SqlConnection con = new SqlConnection(@"Data Source=unitec-db.database.windows.net;
                                                    Initial Catalog=clases;
                                                    User ID=loginAlumno;
                                                    Password=Pa$$word;");
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT [Id], [Nombre], [Cuenta],[Promedio] FROM [ad_Alumnos]", con);
            SqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                alumno.Add(
                    new alumnos{ Id = (Guid)rdr["Id"], Nombre = (string)rdr["Nombre"], cuenta = (int)rdr["Cuenta"], promedio = (double)rdr["Promedio"] });
            }

            con.Close();
        }
         public void OnPost(string nombre, int cuenta,double promedio)

        {
            SqlConnection con = new SqlConnection(@"Data Source=unitec-db.database.windows.net;
                                                    Initial Catalog=clases;
                                                    User ID=loginAlumno;
                                                    Password=Pa$$word;");
            con.Open();

            SqlCommand cmd = new SqlCommand($"INSERT INTO [ad_Alumnos] ([Id],[Nombre],[Cuenta],[Promedio]) VALUES (NEWID(),'{nombre}','{cuenta}',{promedio});", con);
            cmd.ExecuteNonQuery();

            con.Close();

            OnGet();
        }
        public void OnPostDelete(Guid id)
        {
            SqlConnection con = new SqlConnection(@"Data Source=unitec-db.database.windows.net;
                                                    Initial Catalog=clases;
                                                    User ID=loginAlumno;
                                                    Password=Pa$$word;");
            con.Open();

            SqlCommand cmd = new SqlCommand($"DELETE FROM [ad_Alumnos] WHERE [Id] = '{id.ToString()}';", con);
            cmd.ExecuteNonQuery();

            con.Close();

            OnGet();
        }    
        
    }
}